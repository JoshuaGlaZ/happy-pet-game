﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projectUAS
{
    public class fish : pet
    {
        private bool envStatus;
    }
}
